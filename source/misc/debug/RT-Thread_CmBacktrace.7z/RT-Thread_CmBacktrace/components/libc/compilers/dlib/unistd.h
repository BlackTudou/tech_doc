/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 */
#ifndef _UNISTD_H_
#define _UNISTD_H_

# include "sys/unistd.h"

#endif /* _UNISTD_H_ */
