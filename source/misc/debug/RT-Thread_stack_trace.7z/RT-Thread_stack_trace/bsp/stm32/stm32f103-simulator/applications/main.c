/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * Change Logs:
 * Date           Author         Notes
 * 2021-08-20     weidongshan    first version
 */

#include <rtthread.h>
#include <rtdevice.h>

#define THREAD_PRIORITY         15  //设置线程优先级
#define THREAD_STACK_SIZE       512 //设置线程栈大小
#define THREAD_TIMESLICE        15  //设置线程时间片大小

static char thread1_stack[1024];    //设置线程1的内存栈
static struct rt_thread thread1;    //定义线程1句柄

static struct rt_thread *thread2;   //定义线程2句柄指针

typedef void (*func_ptr)(void);

static void A(void);
static void B(void);
static int C(int b);

static void A(void)
{
	rt_kprintf("Enter A()\r\n");
	B();
	rt_kprintf("Exit A()\r\n");
}

static void B(void)
{
	rt_kprintf("Enter B()\r\n");
	C(0);
	rt_kprintf("Exit B()\r\n");
}

static int C(int b)
{
	return 100/b;
}

static void D(void)
{	
	rt_kprintf("Enter D()\r\n");
	C(1);
	rt_kprintf("Exit D()\r\n");
}


/* 线程1的入口函数 */
static void thread1_entry(void *parameter)
{
	const char *thread_name = "Thread1 run\r\n";
	volatile rt_uint32_t cnt = 0;
	
	/* 线程1 */
	while(1)
	{
		/* 打印线程1的信息 */
		rt_kprintf(thread_name);

		A();
		
		/* 延迟一会(比较简单粗暴) */
		for( cnt = 0; cnt < 100000; cnt++ )
		{
		}
	}
}

/* 线程2入口函数 */
static void thread2_entry(void *param)
{
	const char *thread_name = "Thread2 run\r\n";
	volatile rt_uint32_t cnt = 0;
	/* 线程2 */
	while(1)
	{
		/* 打印线程2的信息 */
		rt_kprintf(thread_name);
		D();
		
		/* 延迟一会(比较简单粗暴) */
		for( cnt = 0; cnt < 100000; cnt++ )
		{
		}
	}
}


int main(void)
{
	/* 使能除0错误
	 * CCR(0xE000ED14)的bit4(DIV_0_TRP)设置为1
	 */
	volatile int *CCR = (volatile int *)0xE000ED14;
	*CCR |= (1<<4);

	/* 初始化静态线程1，名称是Thread1，入口是thread1_entry */
    rt_thread_init(&thread1,               //线程句柄 
                   "thread1",              //线程名字
                   thread1_entry,          //入口函数
                   RT_NULL,                //入口函数参数
                   &thread1_stack[0],      //线程栈起始地址
                   sizeof(thread1_stack),  //栈大小
                   THREAD_PRIORITY,        //线程优先级
				   THREAD_TIMESLICE);      //线程时间片大小     
	/* 启动线程1 */
    rt_thread_startup(&thread1);           
	
	
	/* 创建动态线程2，名称是thread2，入口是thread2_entry*/
    thread2 = rt_thread_create("thread2",          //线程名字
                            thread2_entry,     //入口函数
							RT_NULL,           //入口函数参数
                            THREAD_STACK_SIZE, //栈大小
                            THREAD_PRIORITY,   //线程优先级
				            THREAD_TIMESLICE); //线程时间片大小

    /* 判断创建结果,再启动线程2 */
    if (thread2 != RT_NULL)
        rt_thread_startup(thread2);				   
				   
    return 0;
}
